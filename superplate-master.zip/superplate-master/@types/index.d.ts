declare module "parse-github-url";
